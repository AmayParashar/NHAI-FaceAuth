# ── TensorFlow Lite ──────────────────────────────────────────────────────────
-keep class org.tensorflow.** { *; }
-keep class org.tensorflow.lite.** { *; }
-keepclassmembers class org.tensorflow.lite.** { *; }

# ── MediaPipe ────────────────────────────────────────────────────────────────
-keep class com.google.mediapipe.** { *; }

# ── ML Kit ───────────────────────────────────────────────────────────────────
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.** { *; }

# ── SQLCipher ────────────────────────────────────────────────────────────────
-keep class net.zetetic.database.** { *; }

# ── Room ─────────────────────────────────────────────────────────────────────
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keepclassmembers @androidx.room.Entity class * { *; }

# ── FaceAuth module ──────────────────────────────────────────────────────────
-keep class com.datalake.faceauth.** { *; }

# ── WorkManager ──────────────────────────────────────────────────────────────
-keep class * extends androidx.work.Worker
-keep class * extends androidx.work.CoroutineWorker
