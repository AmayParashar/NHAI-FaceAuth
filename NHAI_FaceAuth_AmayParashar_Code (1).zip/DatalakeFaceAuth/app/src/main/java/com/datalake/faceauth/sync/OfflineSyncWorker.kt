package com.datalake.faceauth.sync

import android.content.Context
import android.util.Log
import androidx.work.*
import com.datalake.faceauth.db.FaceAuthDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * WorkManager task that wakes automatically when network connectivity
 * is restored and flushes the local AuthAuditEntity queue to NHAI central DB.
 *
 * Zero audit logs are ever lost — all writes go to Room DB first,
 * and are only marked synced after the server confirms receipt.
 */
class OfflineSyncWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        private const val TAG = "OfflineSyncWorker"
        private const val WORK_NAME = "nhai_audit_sync"
        // Replace with actual NHAI Datalake 3.0 endpoint
        private const val SYNC_ENDPOINT = "https://api.nhai-datalake.gov.in/v1/audit/batch"

        /**
         * Schedule periodic sync — fires automatically when network available.
         * Call once from Application.onCreate().
         */
        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<OfflineSyncWorker>(
                repeatInterval = 15, repeatIntervalTimeUnit = TimeUnit.MINUTES
            )
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
            Log.i(TAG, "Sync worker scheduled")
        }

        /** Force an immediate sync — call when user taps "Force Sync" button */
        fun forceSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = OneTimeWorkRequestBuilder<OfflineSyncWorker>()
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val db = FaceAuthDatabase.getInstance(context)
        val pending = db.authAuditDao().getPendingSync()

        if (pending.isEmpty()) {
            Log.i(TAG, "No pending records to sync")
            return@withContext Result.success()
        }

        Log.i(TAG, "Syncing ${pending.size} audit records to NHAI central DB")

        return@withContext try {
            val payload = JSONArray()
            pending.forEach { entry ->
                payload.put(JSONObject().apply {
                    put("userId",        entry.userId ?: "unknown")
                    put("outcome",       entry.outcome)
                    put("livenessScore", entry.livenessScore)
                    put("matchScore",    entry.matchScore)
                    put("deviceId",      entry.deviceId)
                    put("nonce",         entry.nonce)
                    put("timestamp",     entry.timestamp)
                })
            }

            val url = URL(SYNC_ENDPOINT)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-NHAI-Device", pending.first().deviceId)
            conn.doOutput = true
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000

            conn.outputStream.use { it.write(payload.toString().toByteArray()) }

            if (conn.responseCode in 200..299) {
                val ids = pending.map { it.id }
                db.authAuditDao().markSynced(ids)
                Log.i(TAG, "✓ Synced ${pending.size} records successfully")
                Result.success()
            } else {
                Log.w(TAG, "Server returned ${conn.responseCode} — will retry")
                Result.retry()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Sync failed: ${e.message} — will retry")
            Result.retry()
        }
    }
}
