package com.datalake.faceauth

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.datalake.faceauth.ui.AuthActivity
import com.datalake.faceauth.ui.SupervisorDashboardActivity

/**
 * ════════════════════════════════════════════════════════════════════
 *  DATALAKE 3.0 INTEGRATION POINT
 *  ─────────────────────────────
 *  Drop this class into the existing Datalake 3.0 codebase.
 *  Replace your current AuthManager.verifyIdentity() call with:
 *
 *      val biometric = DatalakeIntegration(this)
 *      biometric.authenticate(driverId) { result ->
 *          when (result) {
 *              is BiometricAuthResult.Granted -> proceedWithAccess(result.userId)
 *              is BiometricAuthResult.Denied  -> showDeniedScreen(result.reason)
 *              is BiometricAuthResult.Fallback -> launchPinEntry()
 *          }
 *      }
 * ════════════════════════════════════════════════════════════════════
 */

sealed class BiometricAuthResult {
    data class Granted(val userId: String, val matchScore: Float, val livenessScore: Float) : BiometricAuthResult()
    data class Denied(val reason: String) : BiometricAuthResult()
    object Fallback : BiometricAuthResult()
}

class DatalakeIntegration(private val activity: AppCompatActivity) {

    private var onResult: ((BiometricAuthResult) -> Unit)? = null

    private val authLauncher: ActivityResultLauncher<Intent> =
        activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            when {
                result.resultCode == Activity.RESULT_OK &&
                data?.getStringExtra("AUTH_RESULT") == "GRANTED" -> {
                    onResult?.invoke(
                        BiometricAuthResult.Granted(
                            userId        = data.getStringExtra("USER_ID") ?: "",
                            matchScore    = data.getFloatExtra("MATCH_SCORE", 0f),
                            livenessScore = data.getFloatExtra("LIVENESS_SCORE", 0f)
                        )
                    )
                }
                data?.getStringExtra("AUTH_RESULT") == "FALLBACK_PIN" -> {
                    onResult?.invoke(BiometricAuthResult.Fallback)
                }
                else -> {
                    onResult?.invoke(BiometricAuthResult.Denied("Authentication cancelled"))
                }
            }
        }

    /**
     * Launch the biometric auth flow for a driver.
     *
     * @param driverId  The driver's ID from Datalake 3.0 records
     * @param callback  Called with the result when auth completes
     */
    fun authenticate(driverId: String, callback: (BiometricAuthResult) -> Unit) {
        onResult = callback
        val intent = Intent(activity, AuthActivity::class.java)
            .putExtra("DRIVER_ID", driverId)
        authLauncher.launch(intent)
    }

    /** Open supervisor dashboard — call from toll plaza manager's device */
    fun openSupervisorDashboard() {
        activity.startActivity(Intent(activity, SupervisorDashboardActivity::class.java))
    }

    companion object {
        /**
         * Quick connectivity-independent check — call before attempting
         * to authenticate to confirm the biometric module is ready.
         */
        fun isModuleReady(context: Context): Boolean {
            return try {
                context.assets.list("")?.contains("mobile_face_net.tflite") == true
            } catch (e: Exception) {
                false
            }
        }
    }
}
