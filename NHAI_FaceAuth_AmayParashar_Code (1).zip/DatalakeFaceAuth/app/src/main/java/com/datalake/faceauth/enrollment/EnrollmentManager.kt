package com.datalake.faceauth.enrollment

import android.content.Context
import android.graphics.Bitmap
import com.datalake.faceauth.db.FaceAuthDatabase
import com.datalake.faceauth.db.FaceIdentityEntity
import com.datalake.faceauth.model.FaceDetector
import com.datalake.faceauth.model.FaceEmbedding
import com.datalake.faceauth.model.FaceRecognizer
import kotlinx.coroutines.*

data class EnrollmentResult(
    val success: Boolean,
    val userId: String,
    val quality: Float,
    val framesUsed: Int,
    val message: String
)

/**
 * Handles face enrollment for a new user.
 *
 * Captures 5 high-quality frames, extracts 128-d embeddings,
 * averages them into a single robust template, and stores it
 * encrypted in Room DB via SQLCipher.
 *
 * Usage:
 * ```kotlin
 * val manager = EnrollmentManager(context)
 * repeat(5) { manager.addFrame(bitmap) }
 * val result = manager.finalize(userId = "driver_001")
 * ```
 */
class EnrollmentManager(private val context: Context) {

    companion object {
        private const val TARGET_FRAMES     = 5
        private const val MIN_FRAMES        = 3
        private const val MIN_FACE_CONF     = 0.80f
        private const val MIN_EMBED_QUALITY = 0.60f
    }

    private val detector  = FaceDetector(context)
    private val recognizer = FaceRecognizer(context)
    private val db = FaceAuthDatabase.getInstance(context)

    private val collectedEmbeddings = mutableListOf<FaceEmbedding>()
    private val collectedQualities  = mutableListOf<Float>()

    val framesCollected get() = collectedEmbeddings.size
    val isReady get() = collectedEmbeddings.size >= MIN_FRAMES

    /**
     * Try to extract an embedding from this bitmap.
     * Returns true if a good-quality face was found and added.
     */
    suspend fun addFrame(bitmap: Bitmap): Boolean = withContext(Dispatchers.Default) {
        val faces = detector.detect(bitmap)
        if (faces.isEmpty() || faces.first().confidence < MIN_FACE_CONF) return@withContext false

        val face = faces.first()
        val box = face.boundingBox
        val cropped = Bitmap.createBitmap(
            bitmap,
            box.left.toInt().coerceAtLeast(0),
            box.top.toInt().coerceAtLeast(0),
            box.width().toInt().coerceAtMost(bitmap.width - box.left.toInt().coerceAtLeast(0)),
            box.height().toInt().coerceAtMost(bitmap.height - box.top.toInt().coerceAtLeast(0))
        )

        val embedding = recognizer.extractEmbedding(cropped)
        val quality = estimateQuality(bitmap, face.confidence)

        if (quality < MIN_EMBED_QUALITY) return@withContext false

        collectedEmbeddings.add(embedding)
        collectedQualities.add(quality)
        true
    }

    /**
     * Finalize enrollment: average collected embeddings and store in DB.
     * Should be called only when [isReady] == true.
     */
    suspend fun finalize(userId: String): EnrollmentResult = withContext(Dispatchers.IO) {
        if (collectedEmbeddings.size < MIN_FRAMES) {
            return@withContext EnrollmentResult(
                success = false, userId = userId,
                quality = 0f, framesUsed = collectedEmbeddings.size,
                message = "Not enough frames. Capture ${MIN_FRAMES - collectedEmbeddings.size} more."
            )
        }

        // Use top-quality frames if more than needed
        val topEmbeddings = collectedEmbeddings
            .zip(collectedQualities)
            .sortedByDescending { it.second }
            .take(TARGET_FRAMES)
            .map { it.first }

        val avgQuality = collectedQualities.sorted().takeLast(topEmbeddings.size).average().toFloat()
        val averaged   = recognizer.averageEmbeddings(topEmbeddings)

        db.faceIdentityDao().upsert(
            FaceIdentityEntity(
                userId              = userId,
                embedding           = averaged.vector,
                enrolledAt          = System.currentTimeMillis(),
                enrollmentQuality   = avgQuality
            )
        )

        collectedEmbeddings.clear()
        collectedQualities.clear()

        EnrollmentResult(
            success      = true,
            userId       = userId,
            quality      = avgQuality,
            framesUsed   = topEmbeddings.size,
            message      = "Enrollment successful. Quality: ${"%.0f".format(avgQuality * 100)}%"
        )
    }

    private fun estimateQuality(bitmap: Bitmap, faceConfidence: Float): Float {
        // Simplified quality score: combine face confidence + image brightness check
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        val avgBrightness = pixels.map { px ->
            val r = (px shr 16 and 0xFF); val g = (px shr 8 and 0xFF); val b = (px and 0xFF)
            (0.299 * r + 0.587 * g + 0.114 * b)
        }.average().toFloat() / 255f

        val brightnessScore = when {
            avgBrightness < 0.1f -> 0.2f   // too dark
            avgBrightness > 0.9f -> 0.4f   // overexposed
            else                 -> 1.0f
        }
        return (faceConfidence * 0.7f + brightnessScore * 0.3f).coerceIn(0f, 1f)
    }

    fun release() {
        detector.close()
        recognizer.close()
    }
}
