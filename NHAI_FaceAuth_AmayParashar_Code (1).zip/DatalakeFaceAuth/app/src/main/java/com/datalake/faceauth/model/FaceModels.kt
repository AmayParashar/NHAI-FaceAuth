package com.datalake.faceauth.model

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.sqrt

// ─── Delegate helper ──────────────────────────────────────────────────────────

private fun buildInterpreter(context: Context, modelFile: String): Interpreter {
    val model = loadModelFile(context, modelFile)
    val options = Interpreter.Options()

    val compatList = CompatibilityList()
    return when {
        compatList.isDelegateSupportedOnThisDevice -> {
            options.addDelegate(GpuDelegate(compatList.bestOptionsForThisDevice))
            Interpreter(model, options)
        }
        else -> {
            // NNAPI falls back to CPU automatically on unsupported devices
            options.addDelegate(NnApiDelegate())
            Interpreter(model, options)
        }
    }
}

private fun loadModelFile(context: Context, modelFile: String): MappedByteBuffer {
    val fd = context.assets.openFd(modelFile)
    return FileInputStream(fd.fileDescriptor).channel.map(
        FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength
    )
}

// ─── Face Detection ───────────────────────────────────────────────────────────

data class DetectedFace(
    val boundingBox: RectF,
    val confidence: Float,
    /** 5 landmarks: left eye, right eye, nose, left mouth, right mouth */
    val landmarks: Array<FloatArray>
)

class FaceDetector(context: Context) : AutoCloseable {

    // Drop-in: swap for yunet.tflite if bundling YuNet directly
    private val interpreter = buildInterpreter(context, "face_detection_short_range.tflite")

    companion object {
        private const val INPUT_SIZE = 128
        private const val CONF_THRESHOLD = 0.7f
    }

    fun detect(bitmap: Bitmap): List<DetectedFace> {
        val scaled = Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, true)
        val inputBuffer = bitmapToByteBuffer(scaled, INPUT_SIZE, INPUT_SIZE)

        // YuNet output: [1, N, 15] — x, y, w, h, conf, 5×(lmx, lmy)
        val outputBoxes = Array(1) { Array(896) { FloatArray(16) } }
        interpreter.run(inputBuffer, outputBoxes)

        return decodeDetections(outputBoxes[0], bitmap.width, bitmap.height)
    }

    private fun decodeDetections(
        raw: Array<FloatArray>, imgW: Int, imgH: Int
    ): List<DetectedFace> {
        val results = mutableListOf<DetectedFace>()
        for (det in raw) {
            val conf = det[4]
            if (conf < CONF_THRESHOLD) continue
            val x = det[0] * imgW; val y = det[1] * imgH
            val w = det[2] * imgW; val h = det[3] * imgH
            val landmarks = Array(5) { i ->
                floatArrayOf(det[5 + i * 2] * imgW, det[6 + i * 2] * imgH)
            }
            results.add(DetectedFace(RectF(x, y, x + w, y + h), conf, landmarks))
        }
        return results.sortedByDescending { it.confidence }
    }

    override fun close() = interpreter.close()
}

// ─── Face Recognition (MobileFaceNet) ────────────────────────────────────────

data class FaceEmbedding(val vector: FloatArray) {
    /** Cosine similarity in [-1, 1]; ≥ 0.70 is considered a match */
    fun cosineSimilarity(other: FaceEmbedding): Float {
        var dot = 0f; var normA = 0f; var normB = 0f
        for (i in vector.indices) {
            dot  += vector[i] * other.vector[i]
            normA += vector[i] * vector[i]
            normB += other.vector[i] * other.vector[i]
        }
        return if (normA == 0f || normB == 0f) 0f
        else dot / (sqrt(normA) * sqrt(normB))
    }
}

class FaceRecognizer(context: Context) : AutoCloseable {

    private val interpreter = buildInterpreter(context, "mobile_face_net.tflite")

    companion object {
        private const val INPUT_SIZE = 112   // MobileFaceNet standard
        private const val EMBEDDING_SIZE = 128
        const val MATCH_THRESHOLD = 0.70f
    }

    /** Extract 128-d L2-normalised embedding from a cropped, aligned face bitmap */
    fun extractEmbedding(faceBitmap: Bitmap): FaceEmbedding {
        val scaled = Bitmap.createScaledBitmap(faceBitmap, INPUT_SIZE, INPUT_SIZE, true)
        val input = bitmapToByteBuffer(scaled, INPUT_SIZE, INPUT_SIZE, normalize = true)
        val output = Array(1) { FloatArray(EMBEDDING_SIZE) }
        interpreter.run(input, output)
        return FaceEmbedding(l2Normalize(output[0]))
    }

    /** Average multiple embeddings (enrollment from 3–5 frames) */
    fun averageEmbeddings(embeddings: List<FaceEmbedding>): FaceEmbedding {
        val avg = FloatArray(EMBEDDING_SIZE)
        embeddings.forEach { emb -> emb.vector.forEachIndexed { i, v -> avg[i] += v } }
        avg.forEachIndexed { i, v -> avg[i] = v / embeddings.size }
        return FaceEmbedding(l2Normalize(avg))
    }

    private fun l2Normalize(v: FloatArray): FloatArray {
        val norm = sqrt(v.sumOf { (it * it).toDouble() }.toFloat())
        return if (norm == 0f) v else FloatArray(v.size) { v[it] / norm }
    }

    override fun close() = interpreter.close()
}

// ─── Passive Liveness Classifier ─────────────────────────────────────────────

data class PassiveLivenessResult(
    val score: Float,           // 0.0 (spoof) → 1.0 (live)
    val isLive: Boolean,
    val spoofType: SpoofType
)

enum class SpoofType { NONE, PRINTED_PHOTO, SCREEN_REPLAY, MASK, UNKNOWN }

class PassiveLivenessClassifier(context: Context) : AutoCloseable {

    // Fine-tuned MobileNetV2 binary classifier: live vs spoof
    private val interpreter = buildInterpreter(context, "liveness_passive.tflite")

    companion object {
        private const val INPUT_SIZE = 224
        private const val LIVENESS_THRESHOLD = 0.80f
    }

    fun classify(faceBitmap: Bitmap): PassiveLivenessResult {
        val scaled = Bitmap.createScaledBitmap(faceBitmap, INPUT_SIZE, INPUT_SIZE, true)
        val input = bitmapToByteBuffer(scaled, INPUT_SIZE, INPUT_SIZE, normalize = true)

        // Output: [liveness_score, printed_score, screen_score, mask_score]
        val output = Array(1) { FloatArray(4) }
        interpreter.run(input, output)

        val live = output[0][0]
        val spoofType = when (output[0].drop(1).indexOf(output[0].drop(1).max())) {
            0 -> SpoofType.PRINTED_PHOTO
            1 -> SpoofType.SCREEN_REPLAY
            2 -> SpoofType.MASK
            else -> SpoofType.UNKNOWN
        }
        return PassiveLivenessResult(
            score = live,
            isLive = live >= LIVENESS_THRESHOLD,
            spoofType = if (live >= LIVENESS_THRESHOLD) SpoofType.NONE else spoofType
        )
    }

    override fun close() = interpreter.close()
}

// ─── Shared buffer utility ────────────────────────────────────────────────────

fun bitmapToByteBuffer(
    bitmap: Bitmap,
    width: Int,
    height: Int,
    normalize: Boolean = false
): ByteBuffer {
    val buffer = ByteBuffer.allocateDirect(1 * width * height * 3 * 4)
        .order(ByteOrder.nativeOrder())
    val pixels = IntArray(width * height)
    bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
    pixels.forEach { px ->
        val r = (px shr 16 and 0xFF).toFloat()
        val g = (px shr 8  and 0xFF).toFloat()
        val b = (px        and 0xFF).toFloat()
        if (normalize) {
            buffer.putFloat((r - 127.5f) / 128f)
            buffer.putFloat((g - 127.5f) / 128f)
            buffer.putFloat((b - 127.5f) / 128f)
        } else {
            buffer.putFloat(r / 255f)
            buffer.putFloat(g / 255f)
            buffer.putFloat(b / 255f)
        }
    }
    buffer.rewind()
    return buffer
}
