package com.datalake.faceauth.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.datalake.faceauth.R
import com.datalake.faceauth.enrollment.EnrollmentManager
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Enrollment screen — captures 5 high-quality face frames,
 * averages them into a single 128-dim template, stores encrypted in Room DB.
 *
 * Called automatically when a driver is not yet enrolled.
 * Supervisor must be present for first-time enrollment at toll plaza.
 */
class EnrollmentActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var tvStatus: TextView
    private lateinit var tvFrameCount: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnEnroll: Button
    private lateinit var layoutSuccess: View

    private lateinit var cameraExecutor: ExecutorService
    private lateinit var enrollmentManager: EnrollmentManager

    private val driverId by lazy {
        intent.getStringExtra("DRIVER_ID") ?: "driver_${System.currentTimeMillis()}"
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startCamera() else finish() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enrollment)

        previewView   = findViewById(R.id.enrollPreviewView)
        tvStatus      = findViewById(R.id.tvEnrollStatus)
        tvFrameCount  = findViewById(R.id.tvFrameCount)
        progressBar   = findViewById(R.id.enrollProgressBar)
        btnEnroll     = findViewById(R.id.btnFinalizeEnroll)
        layoutSuccess = findViewById(R.id.layoutEnrollSuccess)

        enrollmentManager = EnrollmentManager(this)
        cameraExecutor    = Executors.newSingleThreadExecutor()

        tvStatus.text = "Look directly at the camera\nKeep your face in the oval"

        btnEnroll.isEnabled = false
        btnEnroll.setOnClickListener { finalizeEnrollment() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { analysis ->
                    analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                        val bitmap = imageProxy.toBitmap()
                        lifecycleScope.launch {
                            val added = enrollmentManager.addFrame(bitmap)
                            if (added) updateFrameCount()
                        }
                        imageProxy.close()
                    }
                }

            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
                this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, imageAnalyzer
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateFrameCount() {
        val count = enrollmentManager.framesCollected
        runOnUiThread {
            tvFrameCount.text  = "Frames captured: $count / 5"
            progressBar.progress = count * 20  // 0–100
            tvStatus.text = when {
                count < 3 -> "Hold still… capturing frame $count"
                count < 5 -> "Good! Keep holding…"
                else      -> "Ready to enroll!"
            }
            btnEnroll.isEnabled = enrollmentManager.isReady
        }
    }

    private fun finalizeEnrollment() {
        btnEnroll.isEnabled = false
        tvStatus.text = "Saving secure template…"
        lifecycleScope.launch {
            val result = enrollmentManager.finalize(driverId)
            runOnUiThread {
                if (result.success) {
                    layoutSuccess.visibility = View.VISIBLE
                    tvStatus.text = "Enrolled! ${result.message}"
                    previewView.postDelayed({
                        setResult(RESULT_OK)
                        finish()
                    }, 1500)
                } else {
                    tvStatus.text = result.message
                    btnEnroll.isEnabled = true
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        enrollmentManager.release()
        cameraExecutor.shutdown()
    }
}
