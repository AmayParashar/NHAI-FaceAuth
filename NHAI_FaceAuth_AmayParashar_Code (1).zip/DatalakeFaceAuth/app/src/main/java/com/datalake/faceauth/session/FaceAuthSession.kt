package com.datalake.faceauth.session

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.datalake.faceauth.db.AuthAuditEntity
import com.datalake.faceauth.db.FaceAuthDatabase
import com.datalake.faceauth.liveness.*
import com.datalake.faceauth.model.*
import kotlinx.coroutines.*
import java.util.UUID

// ─── Result types ─────────────────────────────────────────────────────────────

sealed class AuthResult {
    data class Granted(
        val userId: String,
        val matchScore: Float,
        val livenessScore: Float,
        val latencyMs: Long
    ) : AuthResult()

    data class Denied(
        val reason: DenialReason,
        val livenessScore: Float,
        val matchScore: Float
    ) : AuthResult()

    object NoFaceDetected : AuthResult()
    object EnrollmentRequired : AuthResult()
}

enum class DenialReason {
    LIVENESS_PASSIVE_FAIL,   // Spoof detected by texture/depth check
    LIVENESS_ACTIVE_TIMEOUT, // User didn't complete challenge in time
    LIVENESS_ACTIVE_FAIL,    // Active challenge score too low
    NO_MATCH_FOUND,          // Face not enrolled in system
    LOW_QUALITY_FRAME        // Face too dark/blurry/far
}

// ─── Session state ────────────────────────────────────────────────────────────

enum class SessionState {
    IDLE, DETECTING, PASSIVE_CHECK, ACTIVE_CHALLENGE, RECOGNIZING, COMPLETE
}

data class SessionStatus(
    val state: SessionState,
    val challenge: LivenessChallenge? = null,
    val passiveScore: Float = 0f,
    val frameCount: Int = 0
)

// ─── FaceAuthSession ──────────────────────────────────────────────────────────

/**
 * Top-level orchestrator for offline face authentication.
 * Feed frames via [processFrame]; observe [onStatusUpdate] and [onResult].
 *
 * All ML inference runs on [Dispatchers.Default] (CPU/GPU delegate).
 * DB writes run on [Dispatchers.IO].
 * Callbacks are posted on the calling (main) coroutine context.
 *
 * Usage:
 * ```kotlin
 * val session = FaceAuthSession(context, userId = "user_001")
 * session.onStatusUpdate = { status -> updateUI(status) }
 * session.onResult = { result -> handleAuth(result) }
 * session.start()
 * // feed camera frames:
 * session.processFrame(bitmap)
 * // when done:
 * session.release()
 * ```
 */
class FaceAuthSession(
    private val context: Context,
    private val userId: String,
    private val deviceId: String = android.provider.Settings.Secure.getString(
        context.contentResolver,
        android.provider.Settings.Secure.ANDROID_ID
    ) ?: "unknown"
) {
    companion object {
        private const val TAG = "FaceAuthSession"
        private const val PASSIVE_PASS_THRESHOLD  = 0.80f
        private const val PASSIVE_QUERY_THRESHOLD = 0.65f // below → skip active, straight deny
        private const val MATCH_THRESHOLD         = 0.70f
        private const val MAX_DENIAL_BEFORE_LOCKOUT = 5
        private const val LOCKOUT_WINDOW_MS = 5 * 60 * 1000L
    }

    // ── Model components ────────────────────────────────────────────────────
    private lateinit var faceDetector: FaceDetector
    private lateinit var recognizer: FaceRecognizer
    private lateinit var passiveLiveness: PassiveLivenessClassifier
    private val activeLiveness = ActiveLivenessDetector()

    // ── State ────────────────────────────────────────────────────────────────
    private var state = SessionState.IDLE
    private var passiveScore = 0f
    private var frameCount = 0
    private var activeChallenge: LivenessChallenge? = null
    private var sessionStartMs = 0L
    private val sessionNonce = UUID.randomUUID().toString()

    private val db by lazy { FaceAuthDatabase.getInstance(context) }
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // ── Callbacks ────────────────────────────────────────────────────────────
    var onStatusUpdate: ((SessionStatus) -> Unit)? = null
    var onResult: ((AuthResult) -> Unit)? = null

    // ─────────────────────────────────────────────────────────────────────────

    fun start() {
        scope.launch {
            faceDetector    = FaceDetector(context)
            recognizer      = FaceRecognizer(context)
            passiveLiveness = PassiveLivenessClassifier(context)
            state = SessionState.DETECTING
            sessionStartMs = System.currentTimeMillis()
            postStatus(SessionStatus(state))
            Log.i(TAG, "Session started for userId=$userId nonce=$sessionNonce")
        }
    }

    /**
     * Feed a camera frame. Safe to call from any thread at 30fps.
     * Heavy work is dispatched internally; returns immediately.
     */
    fun processFrame(bitmap: Bitmap) {
        if (state == SessionState.IDLE || state == SessionState.COMPLETE) return
        scope.launch { handleFrame(bitmap) }
    }

    private suspend fun handleFrame(bitmap: Bitmap) {
        frameCount++

        // ── 1. Face detection ──────────────────────────────────────────────
        val faces = faceDetector.detect(bitmap)
        if (faces.isEmpty()) return
        val best = faces.first()
        if (best.confidence < 0.75f) return

        val cropped = cropFace(bitmap, best)

        // ── 2. Passive liveness (every frame) ─────────────────────────────
        if (state == SessionState.DETECTING || state == SessionState.PASSIVE_CHECK) {
            state = SessionState.PASSIVE_CHECK
            val passive = passiveLiveness.classify(cropped)
            passiveScore = passive.score

            postStatus(SessionStatus(state, passiveScore = passiveScore, frameCount = frameCount))

            when {
                passive.score >= PASSIVE_PASS_THRESHOLD -> {
                    // Passive alone is sufficient → go straight to recognition
                    runRecognition(cropped, activePassed = true)
                }
                passive.score >= PASSIVE_QUERY_THRESHOLD -> {
                    // Borderline → trigger active challenge
                    if (state != SessionState.ACTIVE_CHALLENGE) {
                        activeChallenge = LivenessChallenge.random()
                        activeLiveness.startChallenge()
                        state = SessionState.ACTIVE_CHALLENGE
                        postStatus(SessionStatus(state, challenge = activeChallenge,
                            passiveScore = passiveScore))
                    }
                }
                else -> {
                    // Clear spoof signal
                    deny(DenialReason.LIVENESS_PASSIVE_FAIL, passiveScore, 0f)
                }
            }
        }

        // ── 3. Active challenge ────────────────────────────────────────────
        if (state == SessionState.ACTIVE_CHALLENGE) {
            val challenge = activeChallenge ?: return
            // Build landmark list from face detection (simplified — in production
            // feed MediaPipe Face Mesh output here)
            val landmarks = best.landmarks.map {
                android.graphics.PointF(it[0], it[1])
            }.toMutableList()
            // Pad to 468 landmarks if using full Face Mesh (placeholder for integration)

            val frame = ActiveLivenessDetector.FrameAnalysis(
                landmarks = landmarks,
                imageWidth = bitmap.width,
                imageHeight = bitmap.height
            )
            when (val passed = activeLiveness.processFrame(frame, challenge)) {
                true  -> runRecognition(cropped, activePassed = true)
                null  -> deny(DenialReason.LIVENESS_ACTIVE_TIMEOUT, passiveScore, 0f)
                false -> { /* still waiting */ }
            }
        }
    }

    private suspend fun runRecognition(faceBitmap: Bitmap, activePassed: Boolean) {
        state = SessionState.RECOGNIZING
        postStatus(SessionStatus(state))

        val fusion = LivenessScoreFusion.fuse(passiveScore, activePassed)
        if (!fusion.isLive) {
            deny(DenialReason.LIVENESS_ACTIVE_FAIL, fusion.finalScore, 0f)
            return
        }

        // ── Embedding extraction ───────────────────────────────────────────
        val queryEmb = recognizer.extractEmbedding(faceBitmap)

        // ── Match against enrolled identities ─────────────────────────────
        val allIdentities = withContext(Dispatchers.IO) {
            db.faceIdentityDao().getAll()
        }

        if (allIdentities.isEmpty()) {
            complete(AuthResult.EnrollmentRequired)
            return
        }

        val best = allIdentities.maxByOrNull { identity ->
            queryEmb.cosineSimilarity(FaceEmbedding(identity.embedding))
        } ?: run { deny(DenialReason.NO_MATCH_FOUND, fusion.finalScore, 0f); return }

        val matchScore = queryEmb.cosineSimilarity(FaceEmbedding(best.embedding))
        val latency = System.currentTimeMillis() - sessionStartMs

        if (matchScore >= MATCH_THRESHOLD) {
            // ── Grant ──────────────────────────────────────────────────────
            withContext(Dispatchers.IO) {
                db.faceIdentityDao().updateLastVerified(best.userId, System.currentTimeMillis())
                logAudit("GRANTED", fusion.finalScore, matchScore)
            }
            complete(AuthResult.Granted(best.userId, matchScore, fusion.finalScore, latency))
        } else {
            deny(DenialReason.NO_MATCH_FOUND, fusion.finalScore, matchScore)
        }
    }

    private suspend fun deny(reason: DenialReason, livenessScore: Float, matchScore: Float) {
        withContext(Dispatchers.IO) {
            logAudit("DENIED:${reason.name}", livenessScore, matchScore)
        }
        complete(AuthResult.Denied(reason, livenessScore, matchScore))
    }

    private suspend fun logAudit(outcome: String, livenessScore: Float, matchScore: Float) {
        db.authAuditDao().insert(
            AuthAuditEntity(
                userId       = userId,
                outcome      = outcome,
                livenessScore = livenessScore,
                matchScore   = matchScore,
                deviceId     = deviceId,
                nonce        = sessionNonce
            )
        )
    }

    private fun cropFace(bitmap: Bitmap, face: DetectedFace): Bitmap {
        val box = face.boundingBox
        val margin = 0.2f
        val mw = (box.width() * margin).toInt()
        val mh = (box.height() * margin).toInt()
        val x = (box.left - mw).coerceAtLeast(0f).toInt()
        val y = (box.top  - mh).coerceAtLeast(0f).toInt()
        val w = (box.width()  + 2 * mw).toInt().coerceAtMost(bitmap.width  - x)
        val h = (box.height() + 2 * mh).toInt().coerceAtMost(bitmap.height - y)
        return Bitmap.createBitmap(bitmap, x, y, w, h)
    }

    private fun complete(result: AuthResult) {
        state = SessionState.COMPLETE
        postStatus(SessionStatus(SessionState.COMPLETE))
        scope.launch(Dispatchers.Main) { onResult?.invoke(result) }
    }

    private fun postStatus(status: SessionStatus) {
        scope.launch(Dispatchers.Main) { onStatusUpdate?.invoke(status) }
    }

    fun release() {
        if (::faceDetector.isInitialized)    faceDetector.close()
        if (::recognizer.isInitialized)      recognizer.close()
        if (::passiveLiveness.isInitialized) passiveLiveness.close()
        scope.cancel()
        Log.i(TAG, "Session released")
    }
}
