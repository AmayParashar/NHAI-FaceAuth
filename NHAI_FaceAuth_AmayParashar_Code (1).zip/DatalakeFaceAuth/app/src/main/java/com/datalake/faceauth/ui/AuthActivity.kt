package com.datalake.faceauth.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.datalake.faceauth.R
import com.datalake.faceauth.session.*
import com.datalake.faceauth.sync.OfflineSyncWorker
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Screen 1 — Driver Identity Scanning Interface
 *
 * Shows:
 *  • Green "SYSTEM OFFLINE · SECURE EDGE MODE" badge
 *  • Live camera preview with face oval overlay
 *  • Active liveness challenge prompt (blink / nod / smile)
 *  • Live metrics: latency, liveness score, fps
 */
class AuthActivity : AppCompatActivity() {

    // ── Views ────────────────────────────────────────────────────────────────
    private lateinit var previewView: PreviewView
    private lateinit var tvOfflineBadge: TextView
    private lateinit var tvChallenge: TextView
    private lateinit var tvLatency: TextView
    private lateinit var tvLiveness: TextView
    private lateinit var tvFps: TextView
    private lateinit var layoutDenied: View
    private lateinit var tvDeniedReason: TextView
    private lateinit var btnRetry: Button
    private lateinit var btnFallback: Button
    private lateinit var layoutGranted: View
    private lateinit var tvGrantedUser: TextView
    private lateinit var progressBar: ProgressBar

    // ── Camera & session ─────────────────────────────────────────────────────
    private lateinit var cameraExecutor: ExecutorService
    private var faceAuthSession: FaceAuthSession? = null

    // Passed from Datalake 3.0 calling intent
    private val driverId by lazy {
        intent.getStringExtra("DRIVER_ID") ?: "unknown_driver"
    }

    // ── Permission launcher ───────────────────────────────────────────────────
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else showPermissionError()
    }

    // ─────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)
        bindViews()
        setupSession()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }

        cameraExecutor = Executors.newSingleThreadExecutor()
        tvOfflineBadge.text = "● SYSTEM OFFLINE · SECURE EDGE MODE"
    }

    private fun bindViews() {
        previewView    = findViewById(R.id.previewView)
        tvOfflineBadge = findViewById(R.id.tvOfflineBadge)
        tvChallenge    = findViewById(R.id.tvChallenge)
        tvLatency      = findViewById(R.id.tvLatency)
        tvLiveness     = findViewById(R.id.tvLiveness)
        tvFps          = findViewById(R.id.tvFps)
        layoutDenied   = findViewById(R.id.layoutDenied)
        tvDeniedReason = findViewById(R.id.tvDeniedReason)
        btnRetry       = findViewById(R.id.btnRetry)
        btnFallback    = findViewById(R.id.btnFallback)
        layoutGranted  = findViewById(R.id.layoutGranted)
        tvGrantedUser  = findViewById(R.id.tvGrantedUser)
        progressBar    = findViewById(R.id.progressBar)
    }

    private fun setupSession() {
        faceAuthSession = FaceAuthSession(this, userId = driverId)

        faceAuthSession?.onStatusUpdate = { status ->
            runOnUiThread { updateUI(status) }
        }

        faceAuthSession?.onResult = { result ->
            runOnUiThread { handleResult(result) }
        }

        faceAuthSession?.start()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { analysis ->
                    analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                        val bitmap = imageProxy.toBitmap()
                        faceAuthSession?.processFrame(bitmap)
                        imageProxy.close()
                    }
                }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    preview,
                    imageAnalyzer
                )
            } catch (e: Exception) {
                Toast.makeText(this, "Camera init failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateUI(status: SessionStatus) {
        layoutDenied.visibility  = View.GONE
        layoutGranted.visibility = View.GONE

        val challengeText = when (status.state) {
            SessionState.DETECTING      -> "Position your face in the oval"
            SessionState.PASSIVE_CHECK  -> "Hold still… checking liveness"
            SessionState.ACTIVE_CHALLENGE -> "[ ACTION REQUIRED ]  ${status.challenge?.instruction ?: ""}"
            SessionState.RECOGNIZING    -> "Verifying identity…"
            else -> ""
        }
        tvChallenge.text = challengeText
        tvLiveness.text  = if (status.passiveScore > 0)
            "${"%.2f".format(status.passiveScore)}" else "Checking…"
    }

    private fun handleResult(result: AuthResult) {
        when (result) {
            is AuthResult.Granted -> {
                layoutDenied.visibility  = View.GONE
                layoutGranted.visibility = View.VISIBLE
                tvGrantedUser.text = "ACCESS GRANTED\nDriver: ${result.userId}\nLatency: ${result.latencyMs}ms"
                // Return token to Datalake 3.0
                val intent = Intent().apply {
                    putExtra("AUTH_RESULT", "GRANTED")
                    putExtra("USER_ID", result.userId)
                    putExtra("MATCH_SCORE", result.matchScore)
                    putExtra("LIVENESS_SCORE", result.livenessScore)
                }
                setResult(RESULT_OK, intent)
                // Auto-finish after 2s
                previewView.postDelayed({ finish() }, 2000)
            }

            is AuthResult.Denied -> {
                layoutDenied.visibility  = View.VISIBLE
                layoutGranted.visibility = View.GONE
                tvDeniedReason.text = when (result.reason) {
                    DenialReason.LIVENESS_PASSIVE_FAIL   -> "2D Static Media Detected\n(No Micro-Relief Skin Texture Found)"
                    DenialReason.LIVENESS_ACTIVE_TIMEOUT -> "Challenge Timeout\n(No Response Detected)"
                    DenialReason.LIVENESS_ACTIVE_FAIL    -> "Active Challenge Failed\n(Score Below Threshold)"
                    DenialReason.NO_MATCH_FOUND          -> "Identity Not Enrolled\n(No Matching Record Found)"
                    DenialReason.LOW_QUALITY_FRAME       -> "Poor Image Quality\n(Improve Lighting and Distance)"
                }
                btnRetry.setOnClickListener   { restartSession() }
                btnFallback.setOnClickListener { launchPinFallback() }
            }

            AuthResult.EnrollmentRequired -> {
                startActivity(Intent(this, EnrollmentActivity::class.java)
                    .putExtra("DRIVER_ID", driverId))
                finish()
            }

            AuthResult.NoFaceDetected -> { /* camera keeps running */ }
        }
    }

    private fun restartSession() {
        layoutDenied.visibility = View.GONE
        faceAuthSession?.release()
        setupSession()
    }

    private fun launchPinFallback() {
        val intent = Intent().apply { putExtra("AUTH_RESULT", "FALLBACK_PIN") }
        setResult(RESULT_CANCELED, intent)
        finish()
    }

    private fun showPermissionError() {
        Toast.makeText(this, "Camera permission required for biometric auth", Toast.LENGTH_LONG).show()
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        faceAuthSession?.release()
        cameraExecutor.shutdown()
    }
}
