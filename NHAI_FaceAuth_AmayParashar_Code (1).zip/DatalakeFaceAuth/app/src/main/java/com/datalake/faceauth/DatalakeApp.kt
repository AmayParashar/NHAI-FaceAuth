package com.datalake.faceauth

import android.app.Application
import com.datalake.faceauth.db.FaceAuthDatabase
import com.datalake.faceauth.sync.OfflineSyncWorker

class DatalakeApp : Application() {

    /** Lazily initialised encrypted Room DB — shared across the app */
    val faceAuthDb by lazy { FaceAuthDatabase.getInstance(this) }

    override fun onCreate() {
        super.onCreate()
        // Schedule background audit sync — fires whenever Wi-Fi / 4G reconnects
        OfflineSyncWorker.schedule(this)
    }
}
