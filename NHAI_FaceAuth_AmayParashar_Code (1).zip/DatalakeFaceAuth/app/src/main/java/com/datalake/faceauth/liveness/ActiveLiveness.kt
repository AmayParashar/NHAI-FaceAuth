package com.datalake.faceauth.liveness

import android.graphics.PointF
import kotlinx.coroutines.*
import kotlin.math.*

// ─── Landmark indices (MediaPipe Face Mesh 468-point) ─────────────────────────

private object LM {
    // Left eye
    val LEFT_EYE  = intArrayOf(33, 160, 158, 133, 153, 144)
    // Right eye
    val RIGHT_EYE = intArrayOf(362, 385, 387, 263, 373, 380)
    // Mouth corners and lips
    val MOUTH_LEFT  = 61;  val MOUTH_RIGHT = 291
    val MOUTH_TOP   = 13;  val MOUTH_BOTTOM = 14
    // Head pose reference points
    val NOSE_TIP = 1; val CHIN = 152
    val L_CHEEK  = 234; val R_CHEEK = 454
    val L_EYE_CORNER = 33; val R_EYE_CORNER = 263
}

// ─── Eye Aspect Ratio (blink detection) ──────────────────────────────────────

object EyeAspectRatio {
    /**
     * EAR = (‖p2−p6‖ + ‖p3−p5‖) / (2 × ‖p1−p4‖)
     * Typical open-eye EAR ~0.3; blink dips below 0.20
     */
    fun compute(landmarks: List<PointF>, eyeIndices: IntArray): Float {
        fun dist(a: PointF, b: PointF) =
            sqrt((a.x - b.x).pow(2) + (a.y - b.y).pow(2))

        val p = eyeIndices.map { landmarks[it] }
        val vertical = dist(p[1], p[5]) + dist(p[2], p[4])
        val horizontal = 2f * dist(p[0], p[3])
        return if (horizontal < 1e-6f) 0f else vertical / horizontal
    }

    fun avgEar(landmarks: List<PointF>): Float {
        val l = compute(landmarks, LM.LEFT_EYE)
        val r = compute(landmarks, LM.RIGHT_EYE)
        return (l + r) / 2f
    }
}

// ─── Head Pose (yaw/pitch/roll from 2D landmarks) ────────────────────────────

data class HeadPose(val yaw: Float, val pitch: Float, val roll: Float)

object HeadPoseEstimator {
    /**
     * Lightweight 2D approximation — good enough for ±30° challenge detection
     * without a full PnP solver. For higher precision, plug in OpenCV solvePnP.
     */
    fun estimate(landmarks: List<PointF>, imageWidth: Int, imageHeight: Int): HeadPose {
        val noseTip  = landmarks[LM.NOSE_TIP]
        val chin     = landmarks[LM.CHIN]
        val lCheek   = landmarks[LM.L_CHEEK]
        val rCheek   = landmarks[LM.R_CHEEK]
        val lEye     = landmarks[LM.L_EYE_CORNER]
        val rEye     = landmarks[LM.R_EYE_CORNER]

        // Yaw: horizontal asymmetry between cheeks relative to nose
        val faceWidth = (rCheek.x - lCheek.x).coerceAtLeast(1f)
        val noseMidX  = (lCheek.x + rCheek.x) / 2f
        val yaw = ((noseTip.x - noseMidX) / faceWidth) * 90f

        // Pitch: nose tip vs mid-eye-chin vertical ratio
        val midEyeY = (lEye.y + rEye.y) / 2f
        val faceHeight = (chin.y - midEyeY).coerceAtLeast(1f)
        val pitch = ((noseTip.y - midEyeY) / faceHeight - 0.45f) * 160f

        // Roll: angle of the eye-to-eye line
        val dx = rEye.x - lEye.x
        val dy = rEye.y - lEye.y
        val roll = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()

        return HeadPose(yaw, pitch, roll)
    }
}

// ─── Mouth Aspect Ratio (smile / open-mouth) ─────────────────────────────────

object MouthAspectRatio {
    fun compute(landmarks: List<PointF>): Float {
        val left   = landmarks[LM.MOUTH_LEFT]
        val right  = landmarks[LM.MOUTH_RIGHT]
        val top    = landmarks[LM.MOUTH_TOP]
        val bottom = landmarks[LM.MOUTH_BOTTOM]
        fun dist(a: PointF, b: PointF) =
            sqrt((a.x - b.x).pow(2) + (a.y - b.y).pow(2))
        val vertical   = dist(top, bottom)
        val horizontal = dist(left, right).coerceAtLeast(1f)
        return vertical / horizontal
    }
}

// ─── Challenge types ──────────────────────────────────────────────────────────

sealed class LivenessChallenge {
    object Blink        : LivenessChallenge()
    object NodYes       : LivenessChallenge()
    object TurnLeft     : LivenessChallenge()
    object TurnRight    : LivenessChallenge()
    object Smile        : LivenessChallenge()

    val instruction: String get() = when (this) {
        is Blink     -> "Please blink naturally"
        is NodYes    -> "Please nod your head"
        is TurnLeft  -> "Please turn your head left"
        is TurnRight -> "Please turn your head right"
        is Smile     -> "Please smile"
    }

    companion object {
        fun random(): LivenessChallenge {
            val pool = listOf(Blink, NodYes, TurnLeft, TurnRight, Smile)
            return pool.random()
        }
        fun twoRandom(): List<LivenessChallenge> =
            listOf(Blink, NodYes, TurnLeft, TurnRight, Smile).shuffled().take(2)
    }
}

data class ChallengeResult(
    val challenge: LivenessChallenge,
    val passed: Boolean,
    val elapsedMs: Long
)

// ─── Active liveness state machine ───────────────────────────────────────────

class ActiveLivenessDetector {

    companion object {
        private const val BLINK_EAR_THRESHOLD  = 0.20f   // below = eye closed
        private const val BLINK_OPEN_THRESHOLD = 0.28f   // above = eye open again
        private const val YAW_THRESHOLD        = 18f     // degrees for left/right
        private const val PITCH_THRESHOLD      = 12f     // degrees for nod
        private const val SMILE_MAR_THRESHOLD  = 0.15f   // mouth aspect ratio
        private const val CHALLENGE_TIMEOUT_MS = 5_000L
    }

    // Per-frame frame analysis result fed from camera stream
    data class FrameAnalysis(
        val landmarks: List<PointF>,
        val imageWidth: Int,
        val imageHeight: Int,
        val timestampMs: Long = System.currentTimeMillis()
    )

    private var baselinePose: HeadPose? = null
    private var blinkState  = BlinkState.OPEN
    private var startMs     = 0L

    private enum class BlinkState { OPEN, CLOSING, CLOSED }

    fun startChallenge() {
        blinkState = BlinkState.OPEN
        baselinePose = null
        startMs = System.currentTimeMillis()
    }

    /**
     * Feed frames one by one; returns true when the challenge is satisfied.
     * Returns null if challenge has timed out.
     */
    fun processFrame(
        frame: FrameAnalysis,
        challenge: LivenessChallenge
    ): Boolean? {
        if (System.currentTimeMillis() - startMs > CHALLENGE_TIMEOUT_MS) return null

        return when (challenge) {
            is LivenessChallenge.Blink     -> detectBlink(frame)
            is LivenessChallenge.TurnLeft  -> detectYaw(frame, target = -YAW_THRESHOLD)
            is LivenessChallenge.TurnRight -> detectYaw(frame, target = +YAW_THRESHOLD)
            is LivenessChallenge.NodYes    -> detectNod(frame)
            is LivenessChallenge.Smile     -> detectSmile(frame)
        }
    }

    private fun detectBlink(frame: FrameAnalysis): Boolean {
        val ear = EyeAspectRatio.avgEar(frame.landmarks)
        return when (blinkState) {
            BlinkState.OPEN -> {
                if (ear < BLINK_EAR_THRESHOLD) blinkState = BlinkState.CLOSED
                false
            }
            BlinkState.CLOSED -> {
                if (ear > BLINK_OPEN_THRESHOLD) { blinkState = BlinkState.OPEN; true }
                else false
            }
            BlinkState.CLOSING -> false
        }
    }

    private fun detectYaw(frame: FrameAnalysis, target: Float): Boolean {
        val pose = HeadPoseEstimator.estimate(frame.landmarks, frame.imageWidth, frame.imageHeight)
        if (baselinePose == null) baselinePose = pose
        val delta = pose.yaw - (baselinePose?.yaw ?: 0f)
        return if (target < 0) delta < target else delta > target
    }

    private fun detectNod(frame: FrameAnalysis): Boolean {
        val pose = HeadPoseEstimator.estimate(frame.landmarks, frame.imageWidth, frame.imageHeight)
        if (baselinePose == null) { baselinePose = pose; return false }
        val delta = abs(pose.pitch - (baselinePose?.pitch ?: 0f))
        return delta > PITCH_THRESHOLD
    }

    private fun detectSmile(frame: FrameAnalysis): Boolean {
        val mar = MouthAspectRatio.compute(frame.landmarks)
        return mar > SMILE_MAR_THRESHOLD
    }
}

// ─── Score fusion ─────────────────────────────────────────────────────────────

data class LivenessFusionResult(
    val finalScore: Float,
    val isLive: Boolean,
    val passiveScore: Float,
    val activePassed: Boolean
)

object LivenessScoreFusion {
    private const val PASSIVE_WEIGHT = 0.55f
    private const val ACTIVE_WEIGHT  = 0.45f
    private const val FINAL_THRESHOLD = 0.85f

    /**
     * Weighted fusion of passive ML score + active challenge boolean.
     * Active challenge is binarised to 0.0 or 1.0 before weighting.
     */
    fun fuse(passiveScore: Float, activePassed: Boolean): LivenessFusionResult {
        val activeScore = if (activePassed) 1.0f else 0.0f
        val final = PASSIVE_WEIGHT * passiveScore + ACTIVE_WEIGHT * activeScore
        return LivenessFusionResult(
            finalScore    = final,
            isLive        = final >= FINAL_THRESHOLD,
            passiveScore  = passiveScore,
            activePassed  = activePassed
        )
    }
}
