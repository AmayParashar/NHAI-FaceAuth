package com.datalake.faceauth.db

import android.content.Context
import androidx.room.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.nio.ByteBuffer

// ─── Converters ──────────────────────────────────────────────────────────────

class FloatArrayConverter {
    @TypeConverter
    fun fromFloatArray(value: FloatArray): ByteArray {
        val buffer = ByteBuffer.allocate(value.size * 4)
        value.forEach { buffer.putFloat(it) }
        return buffer.array()
    }

    @TypeConverter
    fun toFloatArray(value: ByteArray): FloatArray {
        val buffer = ByteBuffer.wrap(value)
        return FloatArray(value.size / 4) { buffer.float }
    }
}

// ─── Entities ─────────────────────────────────────────────────────────────────

/**
 * Stored face identity — raw images are NEVER persisted.
 * Only the 128-dim MobileFaceNet embedding is stored, encrypted at rest.
 */
@Entity(tableName = "face_identities")
data class FaceIdentityEntity(
    @PrimaryKey val userId: String,
    /** 128-dimensional float embedding, averaged over 3–5 enrollment frames */
    @ColumnInfo(name = "embedding") val embedding: FloatArray,
    @ColumnInfo(name = "enrolled_at") val enrolledAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "last_verified_at") val lastVerifiedAt: Long? = null,
    @ColumnInfo(name = "enrollment_quality") val enrollmentQuality: Float = 0f
) {
    override fun equals(other: Any?) =
        other is FaceIdentityEntity && userId == other.userId
    override fun hashCode() = userId.hashCode()
}

/**
 * Audit log for every auth attempt — synced to Datalake 3.0 on reconnect.
 */
@Entity(tableName = "auth_audit_log")
data class AuthAuditEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "user_id") val userId: String?,
    @ColumnInfo(name = "outcome") val outcome: String,          // "GRANTED" | "DENIED" | "LIVENESS_FAIL"
    @ColumnInfo(name = "liveness_score") val livenessScore: Float,
    @ColumnInfo(name = "match_score") val matchScore: Float,
    @ColumnInfo(name = "device_id") val deviceId: String,
    @ColumnInfo(name = "nonce") val nonce: String,
    @ColumnInfo(name = "timestamp") val timestamp: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "synced") val synced: Boolean = false
)

// ─── DAOs ─────────────────────────────────────────────────────────────────────

@Dao
interface FaceIdentityDao {
    @Query("SELECT * FROM face_identities WHERE userId = :userId LIMIT 1")
    suspend fun getByUserId(userId: String): FaceIdentityEntity?

    @Query("SELECT * FROM face_identities")
    suspend fun getAll(): List<FaceIdentityEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(identity: FaceIdentityEntity)

    @Delete
    suspend fun delete(identity: FaceIdentityEntity)

    @Query("DELETE FROM face_identities WHERE userId = :userId")
    suspend fun deleteByUserId(userId: String)

    @Query("UPDATE face_identities SET last_verified_at = :ts WHERE userId = :userId")
    suspend fun updateLastVerified(userId: String, ts: Long)
}

@Dao
interface AuthAuditDao {
    @Insert
    suspend fun insert(entry: AuthAuditEntity): Long

    @Query("SELECT * FROM auth_audit_log WHERE synced = 0 ORDER BY timestamp ASC")
    suspend fun getPendingSync(): List<AuthAuditEntity>

    @Query("UPDATE auth_audit_log SET synced = 1 WHERE id IN (:ids)")
    suspend fun markSynced(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM auth_audit_log WHERE user_id = :userId AND outcome = 'DENIED' AND timestamp > :since")
    suspend fun recentDenialCount(userId: String, since: Long): Int
}

// ─── Database ─────────────────────────────────────────────────────────────────

@Database(
    entities = [FaceIdentityEntity::class, AuthAuditEntity::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(FloatArrayConverter::class)
abstract class FaceAuthDatabase : RoomDatabase() {

    abstract fun faceIdentityDao(): FaceIdentityDao
    abstract fun authAuditDao(): AuthAuditDao

    companion object {
        @Volatile private var INSTANCE: FaceAuthDatabase? = null

        fun getInstance(context: Context): FaceAuthDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
            }

        private fun buildDatabase(context: Context) =
            Room.databaseBuilder(
                context.applicationContext,
                FaceAuthDatabase::class.java,
                "face_auth.db"
            )
            // Encrypt the database file using Android Keystore-backed key
            .openHelperFactory(getSqlCipherFactory(context))
            .fallbackToDestructiveMigration()
            .build()

        /**
         * Returns an SQLCipher-backed SupportOpenHelperFactory.
         * Key is derived from Android Keystore — never leaves the device.
         */
        private fun getSqlCipherFactory(context: Context): SupportFactory {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            val prefs = EncryptedSharedPreferences.create(
                context, "face_auth_prefs", masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            val passphrase = prefs.getString("db_key", null)
                ?: generateAndStorePassphrase(prefs)
            return SupportFactory(passphrase.toByteArray())
        }

        private fun generateAndStorePassphrase(
            prefs: android.content.SharedPreferences
        ): String {
            val key = java.util.UUID.randomUUID().toString()
            prefs.edit().putString("db_key", key).apply()
            return key
        }
    }
}

// Alias — net.zetetic:android-database-sqlcipher provides this
typealias SupportFactory = net.zetetic.database.sqlcipher.SupportOpenHelperFactory
